from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView, CreateView, UpdateView
from .models import MyModel
from .forms import MyModelForm

# def index(request):
#     return HttpResponse("Hello, world. You're at the polls index.")
# # Create your views here.

# class CreateMyModelView(CreateView):
#     model = MyModel
    #form_class = MyModelForm
    #template_name = 'home.html'
def CreateMyModelView(request):
    model = MyModel
    #form_class = MyModelForm
    form = MyModelForm
    #field_names = [i.name for i in model._meta.get_fields()]
    field_names = ['id', 'name', 'colour', 'food']
    otherData = [[1, 'abc'], [2, 'cde']]
    #create empty content
    content = {"colnames": field_names,
               "other":otherData, 'form': form}
    return render(request, 'home.html', content)

def LoadFood(request):
    colorAns = request.GET.get('color')
    foodDict = {'None':['None'], 'red':['Bean', 'Curry'], 'yellow':['Banana', 'Corn'],
                'blue':['Berries', 'Fish']}
    food =  foodDict[colorAns]
    content = {'foodChoice':food}
    #return HttpResponse("Load Food succesfully")
    return render(request, 'options.html', content)
