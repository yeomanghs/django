from .models import MyModel2, Food2
from django.forms import ModelForm
from django.views.generic import ListView

class MyModelForm2(ModelForm):
    class Meta:
        model = MyModel2
        fields = ['name', 'color', 'food']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['food'].queryset = Food2.objects.none()