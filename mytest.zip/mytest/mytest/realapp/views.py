from django.shortcuts import render
from django.http import HttpResponse
from elasticsearch import Elasticsearch, helpers
from django.views.generic import ListView, CreateView, UpdateView
from django.core.paginator import Paginator
from .models import MyModel2
from .forms import MyModelForm2
from . import es

# def index(request):
#     return HttpResponse("Hello, world. You're at the polls index.")

def showMainPage(request):
    model = MyModel2
    form = MyModelForm2
    otherData = []
    indexName = 'test2'
    userName = 'fiong'
    date = '02 01 2020'

    #connect es
    #es = Elasticsearch([{'host': 'localhost', 'port':9200}])

    #queryInfo = {'match_all':{}}
    #must not have result field in record and match assignee & reported date
    queryInfo = {"bool": {
                    "must_not": {
                        "exists": {
                            "field": "RESULT"
                                }
                                },
                    "must":[
                            {"match": { "ASSIGNEE": userName}},
                            {"match": { 'REPORTED DATE': date}}
                            ]
                        }
                 } 
    res = helpers.scan(es, 
                  query = {"query": queryInfo},
                  index = indexName,
                  size = 1000,
                  request_timeout = 30)

    field_names = ['NO', 'ASSIGNEE',  'RECORD ID',  'OFFENCE TYPE', 'REMOVE', 'JUSTIFICATION']
    #otherData = [[1, 'abc'], [2, 'cde']]
    for no, result in enumerate(res):
        otherData.append([no + 1] + [result['_source'][i] for i in result['_source']
                          if i in ['RECORD ID', 'ASSIGNEE', 'OFFENCE TYPE']])
    #pagination
    page = request.GET.get('page', 1)

    paginator = Paginator(otherData, 10)
    try:
        info = paginator.page(page)
    except PageNotAnInteger:
        info = paginator.page(1)
    except EmptyPage:
        info = paginator.page(paginator.num_pages) 
    #create empty content
    content = {"colnames": field_names,
               "other":info, 'form': form}
    return render(request, 'realhome.html', content)

def loadJustification(request):
    removeAns = request.GET.get('remove')
    removeJustDict = {'None':['None'], 'yes':["Investigation/Production/Freezing Order",
                                            "Mule Account Closing",
                                            "low transaction amount <1m",
                                            "forgery offence",
                                            "keyword of escalation from commercial crime",
                                            "money laundering or unknown offence",
                                            "no other STR reported",
                                            "have police report on the subject",
                                            "insufficient information provided in the STR",
                                            "attempted transaction/ account opening",
                                            "others"
                                                ], 
                    'no':["sensitive names",
                        "sensitive keywords",
                        "related to other offences (previous WFs/ RFIs)",
                        "serious offence e.g. corruption",
                        "amount too high",
                        "linked to other suspicious entities (via str/ctr)",
                        "purpose of tranx susp",
                        "profile of the subjects - NOB/ location is susp",
                        "related to TF",
                        "others"
                        ]}
    justList =  removeJustDict[removeAns]
    content = {'justChoice':justList}
    #return HttpResponse("Load Food succesfully")
    return render(request, 'realoptions.html', content)
