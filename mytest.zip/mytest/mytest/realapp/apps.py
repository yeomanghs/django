from django.apps import AppConfig


class RealappConfig(AppConfig):
    name = 'realapp'
