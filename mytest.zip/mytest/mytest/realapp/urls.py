from django.urls import path

from . import views

urlpatterns = [
#path('', views.CreateMyModelView.as_view()),
    path('', views.showMainPage, name = 'test'),
    path('choice', views.loadJustification, name = 'justification')
]