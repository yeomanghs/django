from mytest.settings import elasticsearch_config
from elasticsearch import Elasticsearch
from datetime import datetime

es = Elasticsearch([{'host': elasticsearch_config['host'], 
                        'port':elasticsearch_config['port']}])