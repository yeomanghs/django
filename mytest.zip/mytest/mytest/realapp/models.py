from django.db import models

JUST_CHOICES = (
    ('None', 'NONE'),
    ('yes', 'YES'),
    ('no','NO')
)

class Color2(models.Model):
  name = models.CharField(max_length = 100, default = None)
  def __str__(self):
    return self.name

class Food2(models.Model):
  color = models.CharField(max_length = 6, choices = JUST_CHOICES, default = 'None')
  #color = models.ForeignKey(Color,  on_delete = models.SET_NULL, null=True)
  name = models.CharField(max_length = 100, default = None)
  def __str__(self):
    return self.name

class MyModel2(models.Model):
  name = models.CharField(max_length = 100, default = None)
  color = models.CharField(max_length = 6, choices = JUST_CHOICES, default = 'None')
  #color = models.ForeignKey(Color, on_delete = models.SET_NULL, null = True)
  food = models.ForeignKey(Food2,  on_delete = models.SET_NULL, null = True)
  def __str__(self):
    return self.name
